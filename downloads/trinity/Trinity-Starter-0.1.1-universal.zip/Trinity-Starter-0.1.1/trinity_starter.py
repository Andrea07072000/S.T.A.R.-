#!/usr/bin/env python3
"""Trinity Starter v0.1.1 — Hardware check, offline S.T.A.R. verification workflows, and safe weight download guide.

Pure Python 3 standard library: zero external dependencies, zero hidden telemetry, zero secrets.
Works completely offline for Option 1 (Explore S.T.A.R.) and archive SHA-256 integrity checks.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import math
import os
import platform
import shutil
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = "0.1.1"
HF_REPO = "STAR-future/Trinity"
HF_REV = "f80e81a37b267383d9e0de9ef0a854c2527304f2"
FULL_WEIGHTS_GB = 1974.93
MIN_FREE_DISK_GB = 2100.0
MIN_GPU_VRAM_GB = 2048.0  # Multi-GPU cluster required for ~1.97 TB MXFP4 checkpoint
STATUS_IT = ("Trinity: 3,56 T parametri, 1.152 esperti per strato MoE, 23.552 nuovi esperti pronti per la "
             "specializzazione scientifica. Gli esempi di questo pacchetto sono calcolati dagli strumenti S.T.A.R.: "
             "ogni risultato con metodo, limiti e ricevuta.")


def detect_ram_gb() -> float | None:
    try:
        if os.name == "nt":
            class _Mem(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            m = _Mem()
            m.dwLength = ctypes.sizeof(_Mem)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                return round(m.ullTotalPhys / (1024 ** 3), 2)
        else:
            meminfo = Path("/proc/meminfo")
            if meminfo.is_file():
                for ln in meminfo.read_text(encoding="utf-8", errors="ignore").splitlines():
                    if ln.startswith("MemTotal:"):
                        return round(int(ln.split()[1]) / (1024 ** 2), 2)
    except Exception:
        return None
    return None


def detect_gpus() -> list[dict[str, object]]:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return []
    try:
        r = subprocess.run(
            [exe, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        if r.returncode != 0:
            return []
        gpus = []
        for ln in r.stdout.splitlines():
            parts = [p.strip() for p in ln.split(",")]
            if len(parts) >= 2:
                gpus.append({"name": parts[0], "vram_gb": round(float(parts[1]) / 1024.0, 2)})
        return gpus
    except Exception:
        return []


def check_hardware(target_dir: Path | None = None) -> dict[str, object]:
    dest = (target_dir or ROOT).resolve()
    du = shutil.disk_usage(dest)
    free_gb = round(du.free / 1e9, 2)
    ram_gb = detect_ram_gb()
    gpus = detect_gpus()
    total_vram_gb = round(sum(float(g["vram_gb"]) for g in gpus), 2)
    can_store = free_gb >= MIN_FREE_DISK_GB
    can_run_full = can_store and total_vram_gb >= MIN_GPU_VRAM_GB
    if can_run_full:
        recommendation = "FULL_WEIGHTS_POSSIBLE_VERIFY_HF_ACCESS"
        summary_it = "Risorse di archiviazione e GPU di classe cluster rilevate: possibile valutare il checkpoint completo."
    elif can_store:
        recommendation = "STORAGE_OK_BUT_CLUSTER_GPU_REQUIRED_FOR_INFERENCE"
        summary_it = (
            f"Spazio disco sufficiente ({free_gb:.1f} GB >= {MIN_FREE_DISK_GB:.0f} GB), ma i pesi completi (~{FULL_WEIGHTS_GB:.1f} GB) "
            "richiedono un cluster multi-GPU per l'inferenza. Usa l'Opzione 1 (strumenti S.T.A.R. locali) su questo computer."
        )
    else:
        recommendation = "USE_STAR_LOCAL_TOOLS_DO_NOT_DOWNLOAD_2TB"
        summary_it = (
            f"Questo computer ha {free_gb:.1f} GB liberi (servono almeno {MIN_FREE_DISK_GB:.0f} GB per i 96 shard da {FULL_WEIGHTS_GB:.1f} GB). "
            "Non scaricare i pesi completi qui: usa l'Opzione 1 (strumenti S.T.A.R. locali, offline e immediati)."
        )
    return {
        "starter_version": VERSION,
        "checked_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "os": f"{platform.system()} {platform.release()}",
        "python": platform.python_version(),
        "cpu_cores": os.cpu_count(),
        "ram_gb": ram_gb,
        "target_path_free_gb": free_gb,
        "gpus": gpus,
        "total_vram_gb": total_vram_gb,
        "trinity_full_weights_gb": FULL_WEIGHTS_GB,
        "trinity_min_disk_gb": MIN_FREE_DISK_GB,
        "can_store_full_weights": can_store,
        "can_run_full_weights_locally": can_run_full,
        "recommendation": recommendation,
        "summary_it": summary_it,
    }


def run_orbit_workflow(alt_km: float = 550.0, inc_deg: float = 51.6, out_dir: Path | None = None) -> dict[str, object]:
    """Option 1A — S.T.A.R. Orbital Physics Verification (RK4 vs Analytical Kepler Cross-Check)."""
    mu = 398600.4418  # km^3/s^2 (EGM96/WGS84 standard)
    re_km = 6378.137
    r0 = re_km + float(alt_km)
    v_circ = math.sqrt(mu / r0)
    period_s = 2.0 * math.pi * math.sqrt((r0 ** 3) / mu)
    inc = math.radians(float(inc_deg))

    # Independent numerical 3D Cartesian RK4 integration for 1 full orbit (2,000 steps)
    y = [r0, 0.0, 0.0, 0.0, v_circ * math.cos(inc), v_circ * math.sin(inc)]

    def deriv(s):
        x, yy, z, vx, vy, vz = s
        rmag = math.sqrt(x * x + yy * yy + z * z)
        fac = -mu / (rmag ** 3)
        return [vx, vy, vz, fac * x, fac * yy, fac * z]

    n_steps = 2000
    dt = period_s / n_steps
    for _ in range(n_steps):
        k1 = deriv(y)
        k2 = deriv([y[i] + 0.5 * dt * k1[i] for i in range(6)])
        k3 = deriv([y[i] + 0.5 * dt * k2[i] for i in range(6)])
        k4 = deriv([y[i] + dt * k3[i] for i in range(6)])
        y = [y[i] + (dt / 6.0) * (k1[i] + 2.0 * k2[i] + 2.0 * k3[i] + k4[i]) for i in range(6)]

    r_end = math.sqrt(y[0] ** 2 + y[1] ** 2 + y[2] ** 2)
    v_end = math.sqrt(y[3] ** 2 + y[4] ** 2 + y[5] ** 2)
    e0 = 0.5 * (v_circ ** 2) - mu / r0
    e1 = 0.5 * (v_end ** 2) - mu / r_end
    energy_rel_err = abs(e1 - e0) / abs(e0)
    closure_err_km = math.sqrt((y[0] - r0) ** 2 + y[1] ** 2 + y[2] ** 2)

    # Analytical LEO->GEO with plane change: 2-burn (Hohmann, plane change at apogee) vs 3-burn (bi-elliptic ra=160,000 km,
    # plane change at the far apoapsis), illustrative comparison in the same two-body impulsive model
    r_geo = 42164.137
    v_leo = v_circ
    v_geo = math.sqrt(mu / r_geo)
    a_t = 0.5 * (r0 + r_geo)
    v_p = math.sqrt(mu * (2.0 / r0 - 1.0 / a_t))
    v_a = math.sqrt(mu * (2.0 / r_geo - 1.0 / a_t))
    dv_2burn_apogee_inc = abs(v_p - v_leo) + math.sqrt(v_a ** 2 + v_geo ** 2 - 2.0 * v_a * v_geo * math.cos(inc))

    ra_bi = 160000.0
    a1 = 0.5 * (r0 + ra_bi)
    a2 = 0.5 * (r_geo + ra_bi)
    v_p1 = math.sqrt(mu * (2.0 / r0 - 1.0 / a1))
    v_a1 = math.sqrt(mu * (2.0 / ra_bi - 1.0 / a1))
    v_a2 = math.sqrt(mu * (2.0 / ra_bi - 1.0 / a2))
    v_p2 = math.sqrt(mu * (2.0 / r_geo - 1.0 / a2))
    dv_3burn_bi = abs(v_p1 - v_leo) + math.sqrt(v_a1 ** 2 + v_a2 ** 2 - 2.0 * v_a1 * v_a2 * math.cos(inc)) + abs(v_p2 - v_geo)

    passed = energy_rel_err < 1e-9 and closure_err_km < 1e-4
    receipt = {
        "workflow_id": "STAR-STARTER-ORBIT-CROSSCHECK-V1",
        "executed_by": "S.T.A.R. local Python engine (NOT Trinity LLM weights)",
        "timestamp_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "inputs": {"altitude_km": alt_km, "inclination_deg": inc_deg, "mu_km3_s2": mu},
        "results": {
            "circular_velocity_km_s": round(v_circ, 6),
            "orbital_period_min": round(period_s / 60.0, 4),
            "rk4_1orbit_closure_err_km": closure_err_km,
            "specific_energy_rel_err": energy_rel_err,
            "illustrative_leo_geo_2burn_km_s": round(dv_2burn_apogee_inc, 5),
            "illustrative_leo_geo_3burn_ra160k_km_s": round(dv_3burn_bi, 5),
            "delta_v_3burn_minus_2burn_m_s": round((dv_3burn_bi - dv_2burn_apogee_inc) * 1000.0, 1),
        },
        "verification": {"energy_tol": 1e-9, "closure_tol_km": 1e-4, "status": "PASS" if passed else "FAIL"},
        "limits_and_assumptions": (
            "Two-body spherical Earth gravity model (no J2/J3/J4, no atmospheric drag, impulsive burns). "
            "Educational and engineering screening workflow only; not certified for flight operations."
        ),
    }
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "receipt_orbit_crosscheck.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    return receipt


def run_adder_workflow(out_dir: Path | None = None) -> dict[str, object]:
    """Option 1B — S.T.A.R. Exhaustive 8-Bit Bounded-Prefix Adder Equivalence Check (all 2^17 = 131,072 inputs)."""
    t0 = time.perf_counter()

    def prefix_add8(a: int, b: int, cin: int) -> int:
        # Bit-level carry-generate / carry-propagate prefix network (depth 3 vs ripple depth 8)
        g = [(a >> i) & (b >> i) & 1 for i in range(8)]
        p = [((a >> i) ^ (b >> i)) & 1 for i in range(8)]
        # Level 1 (stride 1)
        g1, p1 = g[:], p[:]
        for i in range(1, 8):
            g1[i] = g[i] | (p[i] & g[i - 1])
            p1[i] = p[i] & p[i - 1]
        # Level 2 (stride 2)
        g2, p2 = g1[:], p1[:]
        for i in range(2, 8):
            g2[i] = g1[i] | (p1[i] & g1[i - 2])
            p2[i] = p1[i] & p1[i - 2]
        # Level 3 (stride 4)
        g3, p3 = g2[:], p2[:]
        for i in range(4, 8):
            g3[i] = g2[i] | (p2[i] & g2[i - 4])
            p3[i] = p2[i] & p2[i - 4]
        out = 0
        c_prev = cin
        for i in range(8):
            s_i = p[i] ^ c_prev
            out |= (s_i << i)
            c_prev = g3[i] | (p3[i] & cin)
        out |= (c_prev << 8)
        return out

    mismatches = 0
    total = 0
    for cin in (0, 1):
        for a in range(256):
            for b in range(256):
                total += 1
                if prefix_add8(a, b, cin) != (a + b + cin):
                    mismatches += 1
    elapsed_s = round(time.perf_counter() - t0, 3)
    receipt = {
        "workflow_id": "STAR-STARTER-ADDER8-EXHAUSTIVE-V1",
        "executed_by": "S.T.A.R. local Python verifier (NOT Trinity LLM weights)",
        "timestamp_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "inputs_checked_exhaustively": total,
        "expected_state_space": 2 ** 17,
        "mismatches": mismatches,
        "prefix_logic_depth": 3,
        "ripple_carry_baseline_depth": 8,
        "elapsed_sec": elapsed_s,
        "status": "PASS" if (total == 131072 and mismatches == 0) else "FAIL",
        "limits_and_assumptions": (
            "Verifies functional bit-level boolean equivalence of an 8-bit prefix tree across all 131,072 inputs. "
            "Does not model physical wire capacitance, standard-cell timing, or post-layout parasitics."
        ),
    }
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "receipt_adder8_exhaustive.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    return receipt


def verify_integrity(root: Path = ROOT) -> dict[str, object]:
    sums_path = root / "SHA256SUMS.txt"
    if not sums_path.is_file():
        return {"status": "FAIL", "reason": "SHA256SUMS.txt missing"}
    checked, bad = 0, []
    for ln in sums_path.read_text(encoding="utf-8").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        expected, rel = ln.split(None, 1)
        fp = root / rel.strip()
        if not fp.is_file():
            bad.append({"file": rel, "error": "MISSING"})
            continue
        actual = hashlib.sha256(fp.read_bytes()).hexdigest()
        checked += 1
        if actual != expected:
            bad.append({"file": rel, "error": "MISMATCH", "expected": expected, "actual": actual})
    return {"status": "PASS" if (checked > 0 and not bad) else "FAIL", "files_verified": checked, "failures": bad}


def weights_download_plan(dest: Path, force: bool = False) -> dict[str, object]:
    hw = check_hardware(dest)
    blocked_by_disk = (not bool(hw["can_store_full_weights"])) and (not force)
    cmd = f"hf auth login && hf download {HF_REPO} --revision {HF_REV} --local-dir \"{dest}\""
    return {
        "repo_id": HF_REPO,
        "pinned_revision": HF_REV,
        "full_weights_gb": FULL_WEIGHTS_GB,
        "shards": 96,
        "model_status": STATUS_IT,
        "hf_access_note": (
            "Download from Hugging Face with resume support; read LICENSE in the repository before use."
        ),
        "free_disk_gb": hw["target_path_free_gb"],
        "min_required_disk_gb": MIN_FREE_DISK_GB,
        "blocked_by_insufficient_disk": blocked_by_disk,
        "resumable_command": cmd,
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Trinity Starter v0.1.0 (S.T.A.R. local guide & scientific workflows)")
    ap.add_argument("--check-hardware", action="store_true", help="Diagnose RAM, disk space and GPU vs full weights")
    ap.add_argument("--demo-orbit", action="store_true", help="Run S.T.A.R. offline RK4 vs Kepler orbit cross-check")
    ap.add_argument("--demo-adder", action="store_true", help="Run S.T.A.R. exhaustive 8-bit prefix-adder check")
    ap.add_argument("--verify-integrity", action="store_true", help="Verify SHA256SUMS.txt of all Starter files")
    ap.add_argument("--download-weights-plan", action="store_true", help="Check disk space and print safe resumable HF command")
    ap.add_argument("--open-guide", action="store_true", help="Open the offline interactive HTML guide in your browser")
    ap.add_argument("--smoke-test", action="store_true", help="Run all offline checks and emit JSON verdict")
    ap.add_argument("--receipts-dir", default=str(ROOT / "receipts"))
    a = ap.parse_args(argv)
    rdir = Path(a.receipts_dir)

    if a.smoke_test:
        hw = check_hardware(ROOT)
        integ = verify_integrity(ROOT)
        orb = run_orbit_workflow(out_dir=rdir)
        add = run_adder_workflow(out_dir=rdir)
        plan = weights_download_plan(ROOT, force=False)
        ok = (integ["status"] == "PASS") and (orb["verification"]["status"] == "PASS") and (add["status"] == "PASS")
        print(json.dumps({
            "smoke_test": "PASS" if ok else "FAIL",
            "hardware": hw,
            "integrity": integ,
            "orbit_workflow": orb,
            "adder_workflow": add,
            "weights_plan": plan,
        }, indent=2))
        return 0 if ok else 1

    if a.open_guide:
        webbrowser.open((ROOT / "index.html").resolve().as_uri())
        return 0
    if a.check_hardware:
        print(json.dumps(check_hardware(ROOT), indent=2))
        return 0
    if a.demo_orbit:
        print(json.dumps(run_orbit_workflow(out_dir=rdir), indent=2))
        return 0
    if a.demo_adder:
        print(json.dumps(run_adder_workflow(out_dir=rdir), indent=2))
        return 0
    if a.verify_integrity:
        res = verify_integrity(ROOT)
        print(json.dumps(res, indent=2))
        return 0 if res["status"] == "PASS" else 1
    if a.download_weights_plan:
        print(json.dumps(weights_download_plan(ROOT), indent=2))
        return 0

    # Default interactive mode: friendly 3-choice menu + guide launch
    print("=== Benvenuto in Trinity Starter v0.1.1 (S.T.A.R.) ===")
    print(STATUS_IT)
    hw = check_hardware(ROOT)
    print(f"OS: {hw['os']} | CPU: {hw['cpu_cores']} core | RAM: {hw['ram_gb']} GB | Disco libero: {hw['target_path_free_gb']} GB")
    print("Stato:", hw["summary_it"])
    print("\nScegli un percorso:")
    print("  [1] Esplora S.T.A.R. (offline: verifica orbita RK4 + addizionatore 8-bit 131.072 stati)")
    print("  [2] Apri la guida interattiva offline nel browser (index.html)")
    print("  [3] Controlla requisiti e comando sicuro per i pesi completi (~1.974,9 GB, ricerca)")
    print("  [4] Verifica integrita' SHA-256 dei file di questo pacchetto")
    try:
        ch = input("Scelta [1-4, Invio=2]: ").strip() or "2"
    except EOFError:
        ch = "1"
    if ch == "1":
        print(json.dumps(run_orbit_workflow(out_dir=rdir), indent=2))
        print(json.dumps(run_adder_workflow(out_dir=rdir), indent=2))
        print(f"Ricevute salvate in: {rdir}")
    elif ch == "2":
        webbrowser.open((ROOT / "index.html").resolve().as_uri())
    elif ch == "3":
        print(json.dumps(weights_download_plan(ROOT), indent=2))
    elif ch == "4":
        print(json.dumps(verify_integrity(ROOT), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
