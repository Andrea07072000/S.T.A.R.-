@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   Trinity Starter v0.1.1 - S.T.A.R.
echo   Guida locale e strumenti scientifici verificabili
echo ============================================================
start "" "%~dp0index.html"
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>&1
if errorlevel 1 goto nopython
echo.
echo Python 3 trovato: controllo dell'hardware e menu S.T.A.R.
python "%~dp0trinity_starter.py"
goto end
:nopython
echo.
echo La guida interattiva index.html e' aperta nel browser.
echo Per il laboratorio orbitale nel browser Python non serve.
:end
pause
