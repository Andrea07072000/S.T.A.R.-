#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "=== Trinity Starter v0.1.1 (S.T.A.R.) ==="
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$DIR/index.html" >/dev/null 2>&1 || true
elif command -v open >/dev/null 2>&1; then
  open "$DIR/index.html" >/dev/null 2>&1 || true
fi
if command -v python3 >/dev/null 2>&1; then
  python3 "$DIR/trinity_starter.py" "$@"
else
  echo "Open $DIR/index.html in any browser (no Python required for the browser orbit lab)."
fi
