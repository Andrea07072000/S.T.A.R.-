# Trinity Starter v0.1.1 (S.T.A.R.)

**What this archive is:** a lightweight, offline-first entry package for **Trinity + S.T.A.R.**
It checks your hardware before any large download, runs verifiable local S.T.A.R. scientific workflows
with zero external dependencies, and explains clearly how to access the full Trinity research weights
(`~1,974.93 GB`, `96` MXFP4 shards) when running on research/cluster infrastructure.

**What this archive is NOT:** it does not contain the `~1.97 TB` Trinity model weights and does not
claim to run a 3.55T-parameter model on a consumer laptop.

## Trinity in one line
3.56 T parameters, 1,152 experts in every MoE layer, 23,552 new experts ready for scientific specialisation. The
examples in this package are computed by S.T.A.R. tools, each with its method, limits and receipt.

## Quick Start (No Programming Required)
- **Windows:** double-click `Avvia_Trinity_Starter.bat` (or open `index.html` in any browser).
- **Linux / macOS:** run `./start_trinity_starter.sh` (or open `index.html` in any browser).
- **CLI checks (Python 3 stdlib only, zero `pip install`):**
  - `python trinity_starter.py --check-hardware`
  - `python trinity_starter.py --demo-orbit`
  - `python trinity_starter.py --demo-adder`
  - `python trinity_starter.py --verify-integrity`
  - `python trinity_starter.py --download-weights-plan`

## Provenance & Licences
- Starter package & local verification examples: **Apache-2.0** (see `LICENSE` and the full text in `APACHE-2.0.txt`).
- Full Trinity research checkpoint (`https://huggingface.co/STAR-future/Trinity`): derived from
  `moonshotai/Kimi-K3.1-Pro` under the **Kimi K3.1-Pro License** (see `KIMI_K31_PRO_LICENSE.txt`).

## Uninstall
Delete this folder. No system services, background daemons, or registry keys are modified.
