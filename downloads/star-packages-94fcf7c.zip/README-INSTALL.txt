S.T.A.R. packages - offline installation
=========================================

1. Unzip this archive into a folder, for example  star-wheels
2. Open a terminal in the folder that contains star-wheels and run, for the package you need:

       python -m pip install --no-index --find-links star-wheels star-kepler

   (replace star-kepler with any package name; S.T.A.R. dependencies are found in the same folder).
   Packages that need numpy, scipy, sgp4 or mpmath get them from the internet: drop --no-index for those.
3. Check: python -c "import star_kepler; print(star_kepler.__name__)"

Every file's SHA-256 fingerprint is listed in SHA256SUMS.txt. Licence: Apache-2.0 (see LICENSE).
Website: https://andrea07072000.github.io/S.T.A.R.-/

---

Pacchetti S.T.A.R. - installazione senza internet
1. Estrai l'archivio in una cartella, per esempio  star-wheels
2. Apri un terminale nella cartella che contiene star-wheels ed esegui, per il pacchetto che ti serve:
       python -m pip install --no-index --find-links star-wheels star-kepler
3. Prova: python -c "import star_kepler; print(star_kepler.__name__)"
Le impronte SHA-256 sono in SHA256SUMS.txt. Licenza: Apache-2.0 (vedi LICENSE).
